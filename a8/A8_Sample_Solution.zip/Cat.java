/**
 * Cat implementation for A8Q1
 */
public class Cat implements MakesSound {
    public String makeNoise() {
        return "Meeow";
    }
}
