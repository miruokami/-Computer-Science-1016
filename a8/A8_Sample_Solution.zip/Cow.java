/**
 * Cow implementation for A8Q1
 */
public class Cow implements MakesSound {
    public String makeNoise() {
        return "Moo!";
    }
}
