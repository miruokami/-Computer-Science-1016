/**
 * MakesSound interface for Ass 8 Q1
 */
public interface MakesSound {

    public String makeNoise();

}
