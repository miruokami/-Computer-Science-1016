/**
 * Dog implementation for A8Q1
 */
public class Dog implements MakesSound {

    public String makeNoise() {
        return "Woof!";
    }
}
