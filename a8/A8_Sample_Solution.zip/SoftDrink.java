/**
 * Sample SoftDrink implementation for Assignment 8 Q2
 */
public class SoftDrink implements Comparable<SoftDrink> {

    private String colour;
    private String name;
    private int volume;

    public SoftDrink(String colour, String name, int volume) {
        this.colour = colour;
        this.name = name;
        this.volume = volume;
    }

    public int compareTo(SoftDrink o) {
        if (this.name.equals(o.getName())) {
            if (this.colour.equals(o.getColour())) {
                return (this.volume - o.getVolume());
            } else {
                return this.colour.compareTo(o.getColour());
            }
        } else {
            return this.name.compareTo(o.getName());
        }
    }

    public String getColour() {
        return colour;
    }

    public String getName() {
        return name;
    }

    public int getVolume() {
        return volume;
    }

    @Override
    public String toString() {
        return name + " " + colour + " " + volume;
    }
}
