import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import javax.swing.JList;
import javax.swing.JTextField;
import java.util.ArrayList;
   

public class PatternMatcher implements ActionListener {

   private JTextField userInputField;
   // not included in specs:
   private WordList wordlist;
   private JList<String> searchOutputList;

   public PatternMatcher(JTextField userInputField, WordList wordlist, JList<String> searchOutputList) {
      this.userInputField = userInputField;
      this.wordlist = wordlist;
      this.searchOutputList = searchOutputList;
   }
      
   
   public void actionPerformed(ActionEvent e) {
      ArrayList<Word> output = new ArrayList<Word>();
      String input = userInputField.getText();
      
      // checks if legal pattern has been inputted - outputs error message in JList if not
      if (Pattern.legalPattern(input)) {
         Pattern pattern = new Pattern(input);
      
         for (Word word : wordlist) {
            if (pattern.matches(word)) {
               output.add(word);
            }
         }
         
         // make output array - outputs message if there are no matches
         int size = output.size();
         String[] list;
         
         if (size==0) {
            list = new String[]{"No matches. Please try again."};
         }
         else {  
            list = new String[size];
            for (int i=0; i<output.size(); i++) {
               list[i] = output.get(i).toString();
            }
         }
         searchOutputList.setListData(list);
      }
      
      else {
         String[] error = new String[]{"Invalid pattern. Please try again"};
         searchOutputList.setListData(error);
      }
  
   }
}