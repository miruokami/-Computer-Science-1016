import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Scanner;

/**
 * Code for Assignment 8 Q2
 */
public class Question2 {

    public static void main(String[] args) {
        List<SoftDrink> list = new ArrayList<SoftDrink>();
        Scanner s = new Scanner(System.in);
        int option;
        do {
            System.out.println("Enter option: (1) add soft drink (2) quit:");
            option = s.nextInt();
            if (option == 1) {
                System.out.println("Enter name, colour and volume in ml separated by space");
                String name = s.next();
                String colour = s.next();
                int volume = s.nextInt();
                list.add(new SoftDrink(colour, name, volume));
            }

        } while (option != 2);

        Collections.sort(list);

        for (SoftDrink o: list) {
            System.out.println(o);
        }

    }
}
