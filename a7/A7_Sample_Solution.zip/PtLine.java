//An object to provide "co-ordinates" to draw a diagonal line"
//Tighe Barris - BRRTIG001
//30 August 2012
public class PtLine extends VectorObject{
   //Instace variables
   private int x11,y11,x0,y0;
   //Constructor to set instance variables
   public PtLine( int anId, int ax, int ay, int x1,int y1){
      super(anId,ax,ay);
      this.y11 = y1;
      this.x11 = x1;//I've made coppies of the original co-ordinates so they are not altered.
      this.x0 = ax;
      this.y0 = ay;
   }

   //Methods
   public void draw(char [][] matrix){
      //Now begin implementing a formula to calculate where to place the astrixes
      /* Some useful variables
      xx = current x-cord in loop
      yy = current y-cord in loop
      x = begining x point
      y = begining y point
      x1 = ending x point
      y1 = ending y point */
      //Algorithim steps is as follows:
      //Check the slope of the line
      
      int x1 = x11; //These extra local variables do not alter the original co-ordinates :)
      int y1 = y11;
      int x = x0;
      int y = y0;
      
      boolean check = Math.abs(y1-y) > Math.abs(x1-x);
      //If the slope is steep, swaps the x and y co-ords as follows:
      if (check == true){
         //Swap x0 with y0
         int temp = x;
         x = y;
         y = temp;
         //Swap x1 with y1
         temp = x1;
         x1 = y1;
         y1 = temp;
      }
      //The line must always have a smaller starting x-coord so:
      if (x > x1){
         //Swap x with x1
         int temp = x;
         x = x1; 		//This swap forces dx to be positive
         x1 = temp;
         //Swap y with y1
         temp = y;
         y = y1;
         y1 = temp;
      }
      
      //Calculate delta x and delta y for the gradient of the line
      int dx = x1-x;
      int dy = Math.abs(y1-y); //Y-cord may be negative at this point
      
      // These two variables calculate the amount of imprecision that will be produced from later calculations:
      int error = dx/2;
      int ystep; //This variables will be used to determine if to move the 'marker' up or down depending on the slope of the line.
      int yextra =y;
      if (y<y1)
      	ystep = 1;
      else
      	ystep = -1;
      //Implement the drawing algorithm	
      //Begin a loop from 
      for (int i = x;i <=x1;i++){
         if (check == true)
         	matrix[i][yextra] = '*'; //[y-cord][x-cord]
         else
         	matrix[yextra][i] = '*';
         	
         error -= dy;
         if (error < 0){
            yextra+=ystep;
            error +=dx;
         }
         
      }
   
   }


	
}




