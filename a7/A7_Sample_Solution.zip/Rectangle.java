
/**
 * Write a description of class Rectangle here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */
public class Rectangle extends VectorObject {

    private int xLen, yLen;
    
    public Rectangle(final int id, final int x, final int y, final int xLen, final int yLen) {
        super(id, x, y);
        this.xLen = xLen;
        this.yLen = yLen;
    }        


    public void draw(final char [][] matrix) {
        for(int j=0; j<yLen; j++) {
            for(int i=0; i<xLen; i++) {
                matrix[super.y+j][super.x+i]='*';
            }
        }
    }
}
