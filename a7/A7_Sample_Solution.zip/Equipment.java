/**
 * Equipment super class implementation for A5 Q5
 */
public abstract class Equipment {

    protected String serialNumber;
    protected String manufacturer;
    protected String colour;

    protected Equipment(String serialNumber, String manufacturer, String colour) {
        this.serialNumber = serialNumber;
        this.manufacturer = manufacturer;
        this.colour = colour;
    }

    public String getSerialNumber() {
        return serialNumber;
    }

    public String getManufacturer() {
        return manufacturer;
    }

    public String getColour() {
        return colour;
    }
}
