/**
 * A5 Q2 Screen implementation
 */
public class Screen extends Equipment {

    private int size;

    public Screen(String serialNumber, String manufacturer, String colour, int size) {
        super(serialNumber, manufacturer, colour);
        this.size = size;
    }

    public int getSize() {
        return size;
    }

    public String toString() {
        return "Screen: " + serialNumber + ", " + manufacturer + ", " + colour + ", " + size;
    }
}
