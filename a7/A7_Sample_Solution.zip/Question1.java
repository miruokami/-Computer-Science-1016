import java.util.Scanner;

/**
 * A7 Q1 Driver class implementation
 */
public class Question1 {

    private static Equipment[] pieces;

    public static void main(String[] args) {
        Scanner s = new Scanner(System.in);
        System.out.println("Welcome to Great International Technology");
        String option;
        pieces = new Equipment[100];
        int index = 0;
        do {
            System.out.println("MENU: add (B)ox, add (S)creen, add (A)ccessories, (D)elete, (L)ist, (Q)uit");
            option = s.nextLine();
            if ("b".equalsIgnoreCase(option)) {
                System.out.println("Enter the serial number");
                String serial = s.nextLine();
                System.out.println("Enter the manufacturer");
                String man = s.nextLine();
                System.out.println("Enter the colour");
                String colour = s.nextLine();
                System.out.println("Enter the amount of memory (MB)");
                int mem = s.nextInt();
                s.nextLine();
                pieces[index] = new Box(serial, colour, man, mem);
            } else if ("s".equalsIgnoreCase(option)) {
                System.out.println("Enter the serial number");
                String serial = s.nextLine();
                System.out.println("Enter the manufacturer");
                String man = s.nextLine();
                System.out.println("Enter the colour");
                String colour = s.nextLine();
                System.out.println("Enter the screen size in inches");
                int size = s.nextInt();
                s.nextLine();
                pieces[index] = new Screen(serial, colour, man, size);
            } else if ("a".equalsIgnoreCase(option)) {
                System.out.println("Enter the serial number");
                String serial = s.nextLine();
                System.out.println("Enter the manufacturer");
                String man = s.nextLine();
                System.out.println("Enter the colour");
                String colour = s.nextLine();
                pieces[index] = new Accessories(serial, man, colour);
            } else if ("d".equalsIgnoreCase(option)) {
                System.out.println("Enter the serial number");
                String serial = s.nextLine();
                if (delete(serial)) {
                    System.out.println("Done");
                } else {
                    System.out.println("Not found");
                }
            } else if ("l".equalsIgnoreCase(option)) {
                for (Equipment e: pieces) {
                    if (e!=null) {
                        System.out.println(e);
                    }
                }
            }
            if (!option.equalsIgnoreCase("q") && !option.equalsIgnoreCase("d")) {
                System.out.println("Done");
            }
            index++;

        } while (!option.equalsIgnoreCase("q"));
    }

    private static boolean delete(String serial) {
        int deleteIndex = -1;
        for (int i = 0; i < pieces.length; i++) {
            if (pieces[i] != null && pieces[i].serialNumber.equals(serial)) {
                deleteIndex = i;
                break;
            }
        }
        if (deleteIndex >= 0) {
            pieces[deleteIndex] = null;
            return true;
        } else {
            return false;
        }

    }
}
