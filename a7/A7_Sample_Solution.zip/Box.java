/**
 * A5 Q2 Box implementation
 */
public class Box extends Equipment {

    private long memory;

    public Box(String serial, String colour, String manufacturer, long memory) {
        super(serial, manufacturer, colour);
        this.memory = memory;
    }

    public long getMemory() {
        return memory;
    }

    public String toString() {
        return "Box: " + serialNumber + ", " + manufacturer + ", " + colour + ", " + memory;
    }
}
