
/**
 * Write a description of class VLine here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */
public class VLine extends VectorObject {

    private int len;
    
    public VLine(final int id, final int x, final int y, final int len) {
        super(id, x, y);
        this.len = len;
    }

    public void draw(final char [][] matrix) {
        for(int i=0; i<len; i++) {
            matrix[super.y+i][super.x]='*';
        }
    }


}
