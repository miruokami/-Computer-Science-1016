/**
 * A5 Q2 Accessories Implementation
 */
public class Accessories extends Equipment {

    public Accessories(String serialNumber, String manufacturer, String colour) {
        super(serialNumber, manufacturer, colour);
    }

    public String toString() {
        return "Accessories: " + serialNumber + ", " + manufacturer + ", " + colour;
    }

}
