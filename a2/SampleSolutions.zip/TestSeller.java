import java.util.Scanner;
/**
 * Write a description of class TestSeller here.
 *
 * @author Stephan Jamieson
 * @version 22/7/2019
 */
public class TestSeller {

    private TestSeller() {}
    
    public static void main(final String[] args) {
        final Scanner input = new Scanner(System.in);
        System.out.println("Please enter the details of the seller.");
        
        final Seller seller = new Seller();
        
        System.out.print("ID: ");
        seller.ID = input.nextLine();
        
        System.out.print("Name: ");
        seller.name = input.nextLine();
        
        System.out.print("Location: ");
        seller.location = input.nextLine();
        
        System.out.print("Product: ");
        seller.product = input.nextLine();
        
        System.out.print("Price: ");
        final Currency RAND = new Currency("R", "ZAR", 100);
        seller.unit_price = new Money(input.next(), RAND);
        
        System.out.print("Units: ");
        seller.number_of_units = input.nextInt();
        
        System.out.println("The seller has been successfully created:");
        
        System.out.printf("ID of the seller: %s\n", seller.ID);
        System.out.printf("Name of the seller: %s\n", seller.name);
        System.out.printf("Location of the seller: %s\n", seller.location);
        System.out.printf("The product to sell: %s\n", seller.product);
        System.out.printf("Product unit price: %s\n", seller.unit_price);
        System.out.printf("The number of available units: %d\n", seller.number_of_units); 
    }

}
