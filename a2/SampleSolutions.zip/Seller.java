
/**
 * Write a description of class Seller here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */
public class Seller {

    String ID;
    String name;
    String location;
    String product;
    Money unit_price;
    int number_of_units;
    
}
