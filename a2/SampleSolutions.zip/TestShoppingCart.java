
import java.util.Scanner;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author lebeko
 * @date 12 August 2021
 * @version 1.0
 */
public class TestShoppingCart {
    private TestShoppingCart(){
        
    }
    
    public static void main(String[] args){
        
        ShoppingCart basket = new ShoppingCart();
        
        Scanner input = new Scanner(System.in);
        
        System.out.println("How many items would you like to add to your Shopping Cart?:");
        int numOfItems = input.nextInt();
        if (numOfItems == 0){
            System.out.println("Your Shopping Cart is empty.");
        }
        else{
            /* 
             * 
             * Add items to the shopping cart.
             */
            for (int i = 0; i < numOfItems; i++)
            {
                System.out.println("Enter the Product Name:");
                String prodName = input.next();
                System.out.println("Enter the Quantity:");
                int prodQuantity = input.nextInt();
                System.out.println("Enter the Unit Cost:");
                double prodCost = input.nextDouble();
                // Create a new item with product name, quantity and unit price.
                Item item = new Item(prodName, prodQuantity, prodCost);
                // add an item to the Shopping Cart.
                basket.addItems(item);
            }
        
        
            /*
             * Display the list of items in the cart and their quantities
             */
            System.out.println("The Shopping Cart has the following items:");
            basket.queryCart();
            
            System.out.println("--- Shopping Cart with all items ---");
            // Apply the 20% discount coupon
            basket.getDiscount("WELCOME20");

            /* 
             * print the invoice of all items with their quanities, unit price, total amount
             * apply coupon if valid, if not valid there is no discount applicable 
             * add tax to the total amount after discount deduction.
             *
             */

            basket.printInvoice();
        }
    }
}
