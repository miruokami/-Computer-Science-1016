import org.junit.* ;
import static org.junit.Assert.* ;

public class TestOfTime {

   @Test
   public void testOne() {
	  Time time = new Time("12:31");
      assertEquals (time.toString(), "12:31:00");
   }

   @Test
   public void testTwo() {
	   Time earlierTime = new Time("9:45");
	   Time laterTime = new Time("23:50");
	   assertEquals (laterTime.subtract(earlierTime).intValue("second"), ((50+15)+(23-10)*60)*60);
   }

   @Test
   public void testThree() {
	  Time time = new Time("12:31");
      assertEquals (time.subtract(time).intValue("millisecond"), 0);
   }

   @Test
   public void testFour() {
	   Time earlierTime = new Time("00:00");
	   Time laterTime = new Time("01:30:15");
	   assertEquals (laterTime.subtract(earlierTime).intValue("millisecond"), ((1*60+30)*60+15)*1000);
   }

   @Test
   public void testFive() {
	   Time earlierTime = new Time("00:00");
	   Time laterTime = new Time("00:15:15");
	   assertEquals (laterTime.subtract(earlierTime).intValue("second"), (0*60+15)*60+15);
   }

   @Test
   public void testSix() {
	   Time earlierTime = new Time("00:00");
	   Time laterTime = new Time("07:15:15");
	   assertEquals (laterTime.subtract(earlierTime).intValue("minute"), (7*60+15));
   }

   @Test
   public void testSeven() {
	   Time earlierTime = new Time("00:00");
	   Time laterTime = new Time("13:15:15");
	   assertEquals (laterTime.subtract(earlierTime).intValue("hour"), 13);
   }

}
                                                      