public class Shape {
    private String colour, name;

    Shape(String shapeName, String shapeColour) {
        this.name = shapeName;
        this.colour = shapeColour;
    }
    
    Shape(Shape shape){
      this.colour = shape.colour;
      this.name = shape.name;
    }

    public String toString() {
        return name + " " + colour;
    }
}
