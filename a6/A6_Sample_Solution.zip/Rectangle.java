/**
 * A6 Q1 Geometric Shapes Implementation
 *
 */
public class Rectangle extends Shape {

    private double length;
    private double width;

    public Rectangle(String recName, String recColour, double recLength, double recWidth) {
        super(recName, recColour);
        this.length = recLength;
        this.width = recWidth;
    }
    
    public Rectangle (Rectangle rec){
        super(rec);
        this.length = rec.length;
        this.width = rec.width;
    }
    /*
    public double area()
    {
      return length * width;
    }
   */
   
    @Override
    public String toString() {
        return super.toString() + " Length " + length + " Width " + width;
    }
}
