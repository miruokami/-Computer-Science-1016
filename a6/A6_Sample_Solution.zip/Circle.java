/**
 * A6 Q1 Geometric Shapes Implementation
 *
 */
public class Circle extends Shape {

    private double radius;

    public Circle(String name, String colour, double radius) {
        super(name, colour);
        this.radius = radius;
    }
    
    public Circle(Circle circle){
      super(circle);
      this.radius = circle.radius;
    }
    /*
    public double area()
    {
      return Math.PI * Math.pow(radius, 2);
    }
   */
   
    @Override
    public String toString() {
        return super.toString() + " Radius " + radius;
    }
}
