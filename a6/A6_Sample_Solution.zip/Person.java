class Person {

    private String name;
	 private int age;
	 private char gender;// M/F
    
    public Person(String pName, int pAge, char pGender){
      this.name = pName;
      this.age = pAge;
      this.gender = pGender;
    }
    
    public Person(Person person){
      this.name = person.name;
      this.age = person.age;
      this.gender = person.gender; 
    }
	 
	 public void setName(String personName){
	 
	   this.name = personName;
	 
	 }//end setName
	 
	 public void setAge(int personAge){
	 
	   this.age = personAge;
	 }//end setAge
	 
	 public void setGender(char personGender){
	 
	   this.gender = personGender;
	 }//end setGender
	 
	 public String getName(){
	 
	    return this.name;
	 
	 }//end getName
	 
	 public int getAge(){
	 
	    return this.age;
	 
	 }
	 
	 public char getGender(){
	 
	    return this.gender;
	 
	 }
	 
	 //other methods
	 /*
	 public void eat(){
	 
	    System.out.println("eat");
	 
	 }
	 
	 public void sleep(){
	    System.out.println("sleep");
	 }
	 
	 public void shower(){
	    System.out.println("shower");
	 }
*/
}//end Person



