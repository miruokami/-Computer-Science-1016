/**
 * Driver class for question 2 
 *
 * created 10 August, 2013
 * Last edited 30 September 2021
 **/
import java.util.*;

class Question2
{
   public static void main ( String args [] )
   {
      Scanner input = new Scanner(System.in);
		Student owner = new Student(new Student("Thabang", 20, 'M', "UCT", "BComm", 3, "Bowling")); //name of the vehicle owner
		String make;  //make of the vehicle or manufacurer
		int cylinders; //number of cylinders in the engine
		int capacity; //car's seating capacity  
		double weight; //weight of the car
      
		System.out.println("Enter the vehicle manufacturer:");
		   make = input.nextLine();
		System.out.println("Enter the name of the vehicle owner:");
		   owner.setName(input.nextLine());
		System.out.println("Enter the number of cylinders in the engine:");
		   cylinders = input.nextInt();
			
		System.out.println (new Vehicle (cylinders, make, owner)); //create Vehicle object
		
		   input.nextLine(); //clear the \n

		System.out.println("\nEnter the Car manufacturer:");
		   make = input.nextLine(); 
		System.out.println("Enter the name of the car owner:");
		   owner.setName(input.nextLine());
		System.out.println("Enter the number of cylinders in the engine:");
		   cylinders = input.nextInt();
		System.out.println("Enter the car sitting capacity:");
		   capacity = input.nextInt();
		System.out.println("Enter the weight of the car:");
		   weight = input.nextDouble();
		
     System.out.println (new Car (cylinders, make, owner, capacity, weight)); //create car object
     
   }
}
