
public class Car extends Vehicle
{
      private int capacity; //sitting capacity
		private double weight; //weight of the car
      //constructor
      public Car(int numCylinders, String maker, Student name, int passengers, double carWeight)
      {

            super(numCylinders, maker, name);
            this.capacity = passengers;
				this.weight = carWeight;
      }
      
      public Car (Car car){
          super(car);
          this.capacity = car.capacity;
          this.weight = car.weight;
          
      }

      @Override
      public String toString()
      {
            return super.toString()+", "+ capacity +" seater," +" weighs " +weight +" kg";
      }
}

