
class Student extends Person {
    
	 private String nameOfInstitution;
	 private String programOfStudy;
	 private int yearOfStudy;
	 private String hobbies;
	 
    public Student(String name, int age, char gender, String instName, String programme, int year, String hob){
       super(name, age, gender);
       this.nameOfInstitution = instName;
       this.programOfStudy = programme;
       this.yearOfStudy = year;
       this.hobbies = hob;
    }
    
    public Student(Student stud){
       super(stud);
       this.nameOfInstitution = stud.nameOfInstitution;
       this.programOfStudy = stud.nameOfInstitution;
       this.yearOfStudy = stud.yearOfStudy;
       this.hobbies = stud.hobbies;
    }
    
	 public void setNameOfInstitution(String nameOfSchool){
	    this.nameOfInstitution = nameOfSchool;
	 }
	 
	 public void setProgramOfStudy(String program){
	 
	    this.programOfStudy = program;
	 
	 }
	 
	 public void setYearOfStudy(int year){
	    this.yearOfStudy = year;
	 }
	 
	 public void setHobbies(String hobby){
	    this.hobbies = hobby;
	 }
	 
	 public String getNameOfInstitution(){
	    
		 return this.nameOfInstitution;
	 }
	 
	 public String getProgramOfStudy(){
	    
		 return this.programOfStudy;
	 }
	 
	 public int getYearOfStudy(){
	    
		 return this.yearOfStudy;
	 }
	 
	 public String getHobbies(){
	    
		 return this.hobbies;
	 }
	 
	 //other methods, things students do
	 /*
	 public void study(){
	 
	    System.out.println("study");
	 
	 }
	 
	 public void lectures(){
	    System.out.println("attend lectures");
	 
	 }
	 
	 public void extraActivity(){
	 
	    System.out.println("and other extra-curricular activities");
	 
	 }
	 */
	 //added for purposes of Question1
	
}

