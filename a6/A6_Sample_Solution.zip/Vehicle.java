class Vehicle {

    private int cylinders; //number of cylinders in the  engine
    private String manufacturer;
	 private Student owner = new Student(new Student("Gladys", 19, 'F', "UCT", "BSc", 2, "Laughing"));
	 

    public Vehicle(int numCylinders, String maker, Student owner) {
        this.cylinders = numCylinders;
        this.manufacturer = maker;
        this. owner = owner;
    }
    
    public Vehicle(Vehicle vehicle){
       this.cylinders = vehicle.cylinders;
       this.manufacturer = vehicle.manufacturer;
       this.owner = vehicle.owner;
    }
    
    public String toString() {
        return manufacturer + ", " + cylinders + " cylinders, owned by " +owner.getName();
    }
	 
	 

}

   

