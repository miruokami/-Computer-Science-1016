/**
 * Write a description of class NumberUtils here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class NumberUtils {
    
    
    /** 
     * Obtain the length (number of digits) of the given integer.
     */
    public static int numDigits(int number) {
        return (int)Math.floor(Math.log(number)/Math.log(10))+1;
    }
    
    /**
     * Determine whether the given integer contains repeating digits.
     * 
     */
    public static boolean repeats(int number) {
        int[] digits = toArray(number);
        for(int i=0; i<digits.length-1; i++) {
            for(int j=i+1; i<digits.length; i++) {
                if (digits[i]==digits[j]) {
                    return true;
                }
            }
        }
        return false;
    }
                
    
    /**
     * Takes a number n digits in length and returns an array of length n with a digit in each respective 
     * location.
     * e.g. if parameter is 5678 then result is {5, 6, 7, 8}.
     */
    public static int[] toArray(int number) {

        int numDigits = numDigits(number);
        int[] result = new int[numDigits];
    
        for (int place=numDigits-1; place>=0; place--) {
    
            result[place] = number % 10;
            number = number / 10;
        }
        return result;
    }
    
    
    /**
     * Given two numbers, count the quantity of matching digits - that are the same value in the same position.
     * For example, given 39628 and 97324, there are 2 digits in common: x9xx2x.
     * 
     * Assumes that the numbers are the same length and have no repeating digits.
     */
    public static int countMatches(int numberA, int numberB) {
        int count = 0;
        while (numberA>0) {
            if (numberA%10==numberB%10) {
                count++;
            }
            numberA = numberA/10;
            numberB = numberB/10;
        }
        return count;
    }


    /**
     * Count the quantity of digits that the two numbers have in common.
     * 
     * For example, given 39628 and 97324, there are 3 digits in common: 3, 9, 2. 
     */
    public static int countIntersect(int numberA, int numberB) {
        int count = 0;
        final int[] bDigits = NumberUtils.toArray(numberB);
        
        while (numberA>0) {
            final int digit = numberA%10;
            for(int i=0; i<bDigits.length; i++) {
                if (bDigits[i]==digit) {
                    count++;
                    bDigits[i] = -1;
                    break;
                }
            }
            numberA = numberA/10;
        }
        return count;
    }
    

}
