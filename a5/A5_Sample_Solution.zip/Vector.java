public class Vector {

    private double vx;
    private double vy;

    public Vector(double vx, double vy) {
        this.vx = vx;
        this.vy = vy;
    }

    public double getVX() { return vx; }
    public double getVY() { return vy; }
    public double getMagnitude() { return Math.sqrt(Math.pow(vx, 2)+Math.pow(vy, 2)); }
    public Vector add(Vector other) { return new Vector(this.vx+other.vx, this.vy+other.vy); }
    public Vector multiply(double number) { return new Vector(number*vx, number*vy); }
    public double dotProduct(Vector other) { return this.vx*other.vx+this.vy*other.vy; }

    public boolean equals(Object o) {
        if (!(o instanceof Vector)) {
            return false;
        }
        else {
            Vector other = (Vector)o;
            return this.vx==other.vx&&this.vy==other.vy;
        }
    }
    public String toString() { return String.format("v = (%.2f, %.2f)", vx,vy); }

}
