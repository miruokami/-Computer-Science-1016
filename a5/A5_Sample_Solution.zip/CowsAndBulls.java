/**
 * A CowsAndBulls object implements a simple guessing game.
 * 
 * @author Stephan Jamieson
 * @version 30/8/2016
 */
class CowsAndBulls {

    public final static int NUM_DIGITS = 4;
    public final static int MAX_VALUE = 9876;
    public final static int MIN_VALUE = 1234;
    public final static int MAX_GUESSES = 10;
    
    private int secretNumber;
    private int guessesRemaining;
    private boolean gameOver;

    public CowsAndBulls(int seed) {
        NumberPicker numberPicker = new NumberPicker(seed, 1, 9);
        secretNumber = numberPicker.nextInt();
        for(int i=1; i<NUM_DIGITS; i++) {
            secretNumber=secretNumber*10+numberPicker.nextInt();
        }
    	guessesRemaining = MAX_GUESSES;
    	gameOver = false;
    }

    public int guessesRemaining() { return guessesRemaining; }
    
    public Result guess(int number) {
        if (gameOver) {
            throw new RuntimeException("CowsAndBulls : guess : game over");
        }
        else {
            guessesRemaining--;
            int bulls = NumberUtils.countMatches(number, secretNumber);
            if (bulls==NUM_DIGITS) { gameOver=true; }
            int cows = NumberUtils.countIntersect(number, secretNumber)-bulls;
            return new Result(cows, bulls);
        }
    }



    public int giveUp() {
    	gameOver = true;
    	return secretNumber;
    }

    public boolean gameOver() { return gameOver; }
}
