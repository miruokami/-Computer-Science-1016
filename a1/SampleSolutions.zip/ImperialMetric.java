import java.util.Scanner;

public class ImperialMetric{
    
    private ImperialMetric() {}
    
    public static void main (String [] args){
        Scanner sc = new Scanner(System.in);
        System.out.println("Enter the minimum number of feet (not less than 0):");
        int min = sc.nextInt();
        System.out.println("Enter the maximum number of feet (not more than 30):");
        int max = sc.nextInt();
        sc.close();
        System.out.format("%4s%6s%6s%6s%6s%6s%6s%6s%6s%6s%6s%6s%6s\n", "|","0\"","1\"","2\"","3\"","4\"","5\"","6\"","7\"","8\"","9\"","10\"","11\"");
        for (int i = min; i <= max; i++){
            System.out.printf("%-3s",i+"\'");
            System.out.printf("|");
            for(int j =0; j <=11; j++){
                System.out.printf("%6.3f",(i*12+j)*0.0254);
            }
            System.out.format("\n");
        }
    }
}
