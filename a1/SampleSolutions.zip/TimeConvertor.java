import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.*;

public class TimeConvertor {
    private TimeConvertor() {}
    
    public static void main(String [] args) throws ParseException {
        DateFormat analogue = new SimpleDateFormat("h:mm aa");
        DateFormat digital = new SimpleDateFormat("HH:mm");
        Scanner sc = new Scanner(System.in);
        Date time = null;
        System.out.println("Enter a time ([h]h:mm [am|pm]):");
        String input = sc.nextLine();
        if (input.contains("am") || input.contains("pm")) {
            time = analogue.parse(input);
            System.out.println(digital.format(time).toLowerCase());
        } else {
            time = digital.parse(input);
            System.out.println(analogue.format(time).toLowerCase());
        }
    }
}