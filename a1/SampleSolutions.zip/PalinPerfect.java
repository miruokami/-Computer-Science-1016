import java.util.Scanner;

class PalinPerfect
{
   private PalinPerfect() {}
   public static void main ( String [] args )
   {
      Scanner input = new Scanner (System.in);
      
      System.out.println ("Enter the starting point N:");
      int N = input.nextInt();
      System.out.println ("Enter the ending point M:");
      int M = input.nextInt();
         
      System.out.println ("The palindromic perfect squares are as follows:");   
          
      for ( int x = N+1; x<M; x++ )
      {
         boolean perfectSquare = false;
         if (Math.sqrt (x) == (int)Math.sqrt (x))
            perfectSquare = true;
         
         int palindrome = 0;
         int number = x;
         while (number > 0)
         {
            int digit = number % 10;
            number = number / 10;
            palindrome = palindrome * 10 + digit;
         }
         
         if (perfectSquare && (palindrome == x))
            System.out.println (x);
      }
   }
}